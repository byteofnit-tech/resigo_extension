// Initialize PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = 'libs/pdf.worker.min.js';
const { jsPDF } = window.jspdf;

const dropZone = document.getElementById('drop-zone');
const fileInput = document.getElementById('file-input');
const gallery = document.getElementById('gallery');
const progressContainer = document.getElementById('progress-container');
const statusText = document.getElementById('status-text');
const instructionText = document.getElementById('instruction-text');

const modeSelect = document.getElementById('mode-select');

// Settings
const settingsPanel = document.getElementById('output-settings');
const scaleInput = document.getElementById('scale-input');
const scaleVal = document.getElementById('scale-val');
const qualityInput = document.getElementById('quality-input');
const qualityVal = document.getElementById('quality-val');

// Staging Elements
const stagingPanel = document.getElementById('compression-staging');
const stagingFilename = document.getElementById('staging-filename');
const stagingOriginalSize = document.getElementById('staging-original-size');
const stagingEstimate = document.getElementById('staging-estimate');
const btnStartCompress = document.getElementById('btn-start-compress');



// Image Resizer Elements
// const btnResizeImg was removed from HTML
const imgControls = document.getElementById('img-controls'); // Grid container
const scaleGroup = document.getElementById('scale-group'); // To hide in resize mode
const widthInput = document.getElementById('width-input');
const heightInput = document.getElementById('height-input');
const ratioLockBtn = document.getElementById('ratio-lock-btn');

let stagedPdfDoc = null;
let stagedPdfFile = null;
let stagedImgFile = null;
let stagedImgOriginalRatio = null;
let isRatioLocked = true;

// Settings Listeners
scaleInput.addEventListener('input', (e) => {
    scaleVal.textContent = e.target.value + 'x';
    if (currentMode === 'pdf-compress' && stagedPdfDoc) updateSizeEstimate();
});

qualityInput.addEventListener('input', (e) => {
    qualityVal.textContent = e.target.value + '%';
    if (currentMode === 'pdf-compress' && stagedPdfDoc) updateSizeEstimate();
    if (currentMode === 'img-resize' && stagedImgFile) updateImageEstimate();
});
btnStartCompress.addEventListener('click', executeStagedAction);

// Image Controls Listeners
// btnResizeImg listener is removed, handled by dropdown change


ratioLockBtn.addEventListener('click', () => {
    isRatioLocked = !isRatioLocked;
    ratioLockBtn.classList.toggle('active', isRatioLocked);
    const icon = ratioLockBtn.querySelector('svg');
    if (isRatioLocked && widthInput.value) {
        // Re-lock logic: Reset height based on width
        heightInput.value = Math.round(widthInput.value / stagedImgOriginalRatio);
        updateImageEstimate();
    }
});

widthInput.addEventListener('input', () => {
    if (isRatioLocked && stagedImgOriginalRatio) {
        heightInput.value = Math.round(widthInput.value / stagedImgOriginalRatio);
    }
    updateImageEstimate();
});

heightInput.addEventListener('input', () => {
    if (isRatioLocked && stagedImgOriginalRatio) {
        widthInput.value = Math.round(heightInput.value * stagedImgOriginalRatio);
    }
    updateImageEstimate();
});

// === Theme Logic ===
const themeToggle = document.getElementById('theme-toggle');
const iconSun = themeToggle.querySelector('.icon-sun');
const iconMoon = themeToggle.querySelector('.icon-moon');

function initTheme() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    setTheme(savedTheme);
}

function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);

    // Update Icons
    if (theme === 'dark') {
        iconSun.classList.add('hidden');
        iconMoon.classList.remove('hidden');
    } else {
        iconSun.classList.remove('hidden');
        iconMoon.classList.add('hidden');
    }
}

themeToggle.addEventListener('click', () => {
    const currentTheme = localStorage.getItem('theme') === 'dark' ? 'dark' : 'light';
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
});

// Initialize on load
initTheme();

let currentMode = 'pdf-to-jpg'; // 'pdf-to-jpg' | 'jpg-to-pdf' | 'pdf-compress' | 'img-resize'


// === Mode Switching ===

modeSelect.addEventListener('change', (e) => {
    setMode(e.target.value);
});

const dropZoneText = document.getElementById('drop-zone-text');

function setMode(mode) {
    currentMode = mode;
    modeSelect.value = mode; // Sync dropdown if called programmatically

    // Update UI based on mode
    if (mode === 'pdf-to-jpg') {
        instructionText.textContent = 'Drag & Drop a PDF to convert';
        dropZoneText.textContent = 'Drop PDF here';
        fileInput.accept = 'application/pdf';

        settingsPanel.classList.remove('hidden');
        scaleGroup.classList.remove('hidden');
        stagingPanel.classList.add('hidden');
        imgControls.classList.add('hidden');
    } else if (mode === 'jpg-to-pdf') {
        instructionText.textContent = 'Drag & Drop Images to convert';
        dropZoneText.textContent = 'Drop Images here';
        fileInput.accept = 'image/*';

        settingsPanel.classList.remove('hidden');
        scaleGroup.classList.remove('hidden');
        stagingPanel.classList.add('hidden');
        imgControls.classList.add('hidden');
    } else if (mode === 'pdf-compress') {
        instructionText.textContent = 'Drag & Drop a PDF to compress';
        dropZoneText.textContent = 'Drop PDF here';
        fileInput.accept = 'application/pdf';

        // Hide settings initially for staging modes
        settingsPanel.classList.add('hidden');
        scaleGroup.classList.remove('hidden');
        stagingPanel.classList.add('hidden'); // Ensure staging hidden until file drop
        imgControls.classList.add('hidden');
    } else if (mode === 'img-resize') {
        instructionText.textContent = 'Drag & Drop an Image to resize';
        dropZoneText.textContent = 'Drop Image here';
        fileInput.accept = 'image/*';

        settingsPanel.classList.add('hidden');
        // scale slider hidden in logic
        stagingPanel.classList.add('hidden');
        // imgControls hidden until drop
    }

    resetToInput();
}

// === Drag & Drop (Input) ===

dropZone.addEventListener('click', () => fileInput.click());

dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('dragover');
});

dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('dragover');
});

dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');

    const files = Array.from(e.dataTransfer.files);
    if (files.length === 0) return;

    handleFiles(files);
});

fileInput.addEventListener('change', (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;
    handleFiles(files);
});

function handleFiles(files) {
    if (currentMode === 'pdf-to-jpg') {
        const pdfFile = files.find(f => f.type === 'application/pdf');
        if (pdfFile) processPDF(pdfFile);
        else alert('Please drop a PDF file.');
    } else if (currentMode === 'jpg-to-pdf') {
        const imageFiles = files.filter(f => f.type.startsWith('image/'));
        if (imageFiles.length > 0) processImages(imageFiles);
        else alert('Please drop image files.');
    } else if (currentMode === 'pdf-compress') {
        const pdfFile = files.find(f => f.type === 'application/pdf');
        if (pdfFile) stagePDF(pdfFile);
        else alert('Please drop a PDF file to compress.');
    } else if (currentMode === 'img-resize') {
        const imgFile = files.find(f => f.type.startsWith('image/'));
        if (imgFile) stageImage(imgFile);
        else alert('Please drop an image file.');
    }
}


// === PDF -> Images ===

async function processPDF(file) {
    resetUI();
    try {
        const arrayBuffer = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;

        statusText.textContent = `Found ${pdf.numPages} pages...`;

        for (let i = 1; i <= pdf.numPages; i++) {
            statusText.textContent = `Converting page ${i} of ${pdf.numPages}...`;
            await renderPage(pdf, i, file.name);
        }

        finishUI();
    } catch (error) {
        handleError('Error converting PDF: ' + error.message);
    }
}

async function renderPage(pdf, pageNum, originalFileName) {
    const page = await pdf.getPage(pageNum);
    const scale = parseFloat(scaleInput.value);
    const viewport = page.getViewport({ scale: scale });

    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    canvas.height = viewport.height;
    canvas.width = viewport.width;

    await page.render({ canvasContext: context, viewport: viewport }).promise;

    const quality = parseInt(qualityInput.value) / 100;
    const dataUrl = canvas.toDataURL('image/jpeg', quality);

    // Construct filename
    const baseName = originalFileName.replace(/\.pdf$/i, '');
    const fileName = `${baseName}_page_${pageNum}.jpg`;

    addToGallery(dataUrl, fileName, 'image/jpeg', `Page ${pageNum}`);
}


// === Images -> PDF ===

async function processImages(files) {
    resetUI();
    statusText.textContent = 'Generating PDF...';

    try {
        const helperDoc = new jsPDF();
        let doc = null;

        for (let i = 0; i < files.length; i++) {
            statusText.textContent = `Processing image ${i + 1} of ${files.length}...`;

            // Process image (Resize & Compress)
            const imgData = await processAndCompressImage(files[i]);

            // Get dimensions using the helper
            const imgProps = helperDoc.getImageProperties(imgData);

            const w = imgProps.width;
            const h = imgProps.height;
            const orientation = w > h ? 'landscape' : 'portrait';

            if (i === 0) {
                doc = new jsPDF({
                    orientation: orientation,
                    unit: 'px',
                    format: [w, h]
                });
            } else {
                doc.addPage([w, h], orientation);
            }

            doc.addImage(imgData, 'JPEG', 0, 0, w, h);
        }

        if (!doc) throw new Error("No valid images processed.");

        const pdfDataUri = doc.output('datauristring');
        addToGallery(pdfDataUri, 'converted.pdf', 'application/pdf', 'PDF Ready', true);
        finishUI();

    } catch (error) {
        handleError('Error processing images: ' + error.message);
    }
}

function processAndCompressImage(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (event) => {
            const img = new Image();
            img.onload = () => {
                const scale = parseFloat(scaleInput.value) || 1.0;
                const quality = (parseInt(qualityInput.value) || 90) / 100;

                const canvas = document.createElement('canvas');
                canvas.width = img.width * scale;
                canvas.height = img.height * scale;

                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

                const dataUrl = canvas.toDataURL('image/jpeg', quality);
                resolve(dataUrl);
            };
            img.onerror = reject;
            img.src = event.target.result;
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}


// === PDF Compression Logic (Interactive) ===

async function stagePDF(file) {
    resetUI(); // Hides dropzone
    progressContainer.classList.add('hidden'); // Ensure loader is hidden initially

    // UI State for Staging
    settingsPanel.classList.remove('hidden');
    scaleGroup.classList.remove('hidden');
    stagingPanel.classList.remove('hidden');
    imgControls.classList.add('hidden'); // No img controls

    stagedPdfFile = file;
    stagingFilename.textContent = file.name;
    stagingOriginalSize.textContent = `Original: ${formatBytes(file.size)}`;
    stagingEstimate.textContent = "Calculating...";

    try {
        const arrayBuffer = await file.arrayBuffer();
        stagedPdfDoc = await pdfjsLib.getDocument(arrayBuffer).promise;
        updateSizeEstimate();
    } catch (e) {
        handleError("Error loading PDF: " + e.message);
    }
}

async function updateSizeEstimate() {
    if (!stagedPdfDoc) return;

    try {
        // Sample Page 1 for estimation
        const { dataUrl } = await getCompressedPageDataURL(stagedPdfDoc, 1);

        // Base64 size estimation
        const base64Len = dataUrl.length - 'data:image/jpeg;base64,'.length;
        const page1Size = (base64Len * 3) / 4;

        // Estimate Total (Page 1 * Pages * Overhead)
        const estTotal = (page1Size * stagedPdfDoc.numPages) * 1.1;

        const originalSize = stagedPdfFile.size;
        const reduction = Math.round(((originalSize - estTotal) / originalSize) * 100);
        const reductionText = reduction > 0 ? `(-${reduction}%)` : `(+${Math.abs(reduction)}%)`;

        stagingEstimate.textContent = `~${formatBytes(estTotal)} ${reductionText}`;

    } catch (e) {
        console.error(e);
        stagingEstimate.textContent = "Estimate unavailable";
    }
}

async function getCompressedPageDataURL(pdf, pageNum) {
    const page = await pdf.getPage(pageNum);
    const scale = parseFloat(scaleInput.value) || 1.0;
    const viewport = page.getViewport({ scale: scale });

    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    canvas.height = viewport.height;
    canvas.width = viewport.width;

    await page.render({ canvasContext: context, viewport: viewport }).promise;

    const quality = (parseInt(qualityInput.value) || 90) / 100;
    const dataUrl = canvas.toDataURL('image/jpeg', quality);

    return { dataUrl, width: viewport.width, height: viewport.height };
}

function executeStagedAction() {
    if (currentMode === 'pdf-compress' && stagedPdfFile) {
        // Hide staging, show processing
        stagingPanel.classList.add('hidden');
        progressContainer.classList.remove('hidden');
        dropZone.classList.add('hidden');
        settingsPanel.classList.add('hidden'); // optional, hide settings during process

        compressPDF(stagedPdfFile, stagedPdfDoc);

    } else if (currentMode === 'img-resize' && stagedImgFile) {
        processStagedImage();
    }
}

async function compressPDF(file, loadedDoc = null) {
    if (!loadedDoc) {
        const arrayBuffer = await file.arrayBuffer();
        loadedDoc = await pdfjsLib.getDocument(arrayBuffer).promise;
    }

    try {
        const newDoc = new jsPDF();
        const pdf = loadedDoc;

        statusText.textContent = `Compressing ${pdf.numPages} pages...`;

        for (let i = 1; i <= pdf.numPages; i++) {
            statusText.textContent = `Compressing page ${i} of ${pdf.numPages}...`;

            const { dataUrl, width, height } = await getCompressedPageDataURL(pdf, i);

            const orientation = width > height ? 'landscape' : 'portrait';
            if (i > 1) {
                newDoc.addPage([width, height], orientation);
            } else {
                newDoc.deletePage(1);
                newDoc.addPage([width, height], orientation);
            }

            newDoc.addImage(dataUrl, 'JPEG', 0, 0, width, height);
        }

        const pdfDataUri = newDoc.output('datauristring');

        // Calculate Size Stats
        const compressedSize = newDoc.output('arraybuffer').byteLength;
        const sizeInfo = {
            original: file.size,
            compressed: compressedSize
        };

        addToGallery(pdfDataUri, 'compressed.pdf', 'application/pdf', 'Compressed PDF Ready', true, sizeInfo);
        finishUI();

    } catch (error) {
        handleError('Error compressing PDF: ' + error.message);
    }
}


// === Image Resizing Logic (Interactive) ===

function stageImage(file) {
    resetUI();
    progressContainer.classList.add('hidden');

    // UI State for Image Staging
    settingsPanel.classList.remove('hidden');
    scaleGroup.classList.add('hidden'); // Hide scale slider
    stagingPanel.classList.remove('hidden');
    imgControls.classList.remove('hidden'); // Show W/H inputs

    stagedImgFile = file;
    stagingFilename.textContent = file.name;
    stagingOriginalSize.textContent = `Original: ${formatBytes(file.size)}`;
    stagingEstimate.textContent = "Calculating...";

    // Load Image
    const img = new Image();
    img.src = URL.createObjectURL(file);
    img.onload = () => {
        widthInput.value = img.naturalWidth;
        heightInput.value = img.naturalHeight;
        stagedImgOriginalRatio = img.naturalWidth / img.naturalHeight;
        isRatioLocked = true;
        ratioLockBtn.classList.add('active');

        updateImageEstimate();
    };
}

function updateImageEstimate() {
    if (!stagedImgFile) return;

    const w = parseInt(widthInput.value);
    const h = parseInt(heightInput.value);
    const quality = (parseInt(qualityInput.value) || 90) / 100;

    if (!w || !h) return;

    const img = new Image();
    img.src = URL.createObjectURL(stagedImgFile);
    img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);

        canvas.toBlob((blob) => {
            const newSize = blob.size;
            const originalSize = stagedImgFile.size;
            const reduction = Math.round(((originalSize - newSize) / originalSize) * 100);
            const reductionText = reduction > 0 ? `(-${reduction}%)` : `(+${Math.abs(reduction)}%)`;

            stagingEstimate.textContent = `~${formatBytes(newSize)} ${reductionText}`;
        }, 'image/jpeg', quality);
    };
}

async function processStagedImage() {
    // Start processing
    stagingPanel.classList.add('hidden');
    settingsPanel.classList.add('hidden');
    imgControls.classList.add('hidden');
    progressContainer.classList.remove('hidden');
    statusText.textContent = "Resizing Image...";

    const w = parseInt(widthInput.value);
    const h = parseInt(heightInput.value);
    const quality = (parseInt(qualityInput.value) || 90) / 100;

    const img = new Image();
    img.src = URL.createObjectURL(stagedImgFile);
    img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);

        const dataUrl = canvas.toDataURL('image/jpeg', quality);

        // Calculate size for stats
        const head = 'data:image/jpeg;base64,';
        const sizeByte = Math.round((dataUrl.length - head.length) * 3 / 4);

        const sizeInfo = {
            original: stagedImgFile.size,
            compressed: sizeByte
        };

        addToGallery(dataUrl, 'resized_image.jpg', 'image/jpeg', `${w}x${h}`, false, sizeInfo);
        finishUI();
    };
}


// === Helper: Format Bytes ===
function formatBytes(bytes, decimals = 2) {
    if (!+bytes) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}


// === UI Helpers ===

function resetUI() {
    gallery.innerHTML = '';
    gallery.classList.add('hidden');
    progressContainer.classList.remove('hidden');
    dropZone.classList.add('hidden');
    settingsPanel.classList.add('hidden');
    stagingPanel.classList.add('hidden'); // Also hide staging
    instructionText.classList.add('hidden');
}

function resetToInput() {
    gallery.classList.add('hidden');
    progressContainer.classList.add('hidden');
    stagingPanel.classList.add('hidden');
    imgControls.classList.add('hidden'); // Hide img controls

    // Reset inputs
    stagedPdfDoc = null;
    stagedPdfFile = null;
    stagedImgFile = null;

    dropZone.classList.remove('hidden');
    instructionText.classList.remove('hidden');
    gallery.innerHTML = '';
}

function finishUI() {
    progressContainer.classList.add('hidden');
    gallery.classList.remove('hidden');
    // Hide panels
    settingsPanel.classList.add('hidden');
    stagingPanel.classList.add('hidden');
}

function handleError(msg) {
    console.error(msg);
    alert(msg);
    progressContainer.classList.add('hidden');
    dropZone.classList.remove('hidden');
}

function addToGallery(dataUrl, fileName, mimeType, captionText, isPdf = false, sizeInfo = null) {
    const item = document.createElement('div');
    if (isPdf) {
        item.className = 'pdf-item';
        let html = `<div class="pdf-icon">📄</div><div class="pdf-name">${fileName}</div>`;

        if (sizeInfo) {
            const reduction = Math.round(((sizeInfo.original - sizeInfo.compressed) / sizeInfo.original) * 100);
            const colorClass = reduction > 0 ? 'text-green' : 'text-slate';
            const reductionText = reduction > 0 ? `-${reduction}%` : `+${Math.abs(reduction)}%`;

            html += `
            <div class="size-stats">
                <div class="stat-row">
                    <span class="stat-label">Original:</span>
                    <span class="stat-val original">${formatBytes(sizeInfo.original)}</span>
                </div>
                <div class="stat-row">
                    <span class="stat-label">New:</span>
                    <span class="stat-val ${colorClass}">${formatBytes(sizeInfo.compressed)}</span>
                </div>
                <div class="stat-badge ${colorClass}">${reductionText}</div>
            </div>`;
        }
        item.innerHTML = html; /* Removed Overlay Button */
    } else {
        item.className = 'gallery-item';
        item.innerHTML = `<div class="page-label">${captionText}</div>`;

        const img = document.createElement('img');
        img.src = dataUrl;
        item.prepend(img);

        if (sizeInfo) {
            const reduction = Math.round(((sizeInfo.original - sizeInfo.compressed) / sizeInfo.original) * 100);
            const colorClass = reduction > 0 ? 'text-green' : 'text-slate';
            const reductionText = reduction > 0 ? `-${reduction}%` : `+${Math.abs(reduction)}%`;

            // Append stats for image too
            const stats = document.createElement('div');
            stats.innerHTML = `
            <div class="size-stats" style="margin-top: 8px; border-top: 1px solid rgba(0,0,0,0.1); padding-top: 4px;"> 
                <div class="stat-badge ${colorClass}" style="width:100%">${reductionText} (${formatBytes(sizeInfo.compressed)})</div>
            </div>`;
            item.appendChild(stats);
        }
    }



    // Save Button
    const saveBtn = document.createElement('button');
    saveBtn.className = 'save-btn';
    saveBtn.innerHTML = '⬇ Save';
    saveBtn.title = 'Save File';
    saveBtn.onclick = (e) => {
        e.stopPropagation();
        const link = document.createElement('a');
        link.href = dataUrl;
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    item.appendChild(saveBtn);

    // Drag & Drop Output (Images Only)
    if (!isPdf) {
        item.draggable = true;
        item.title = 'Drag to Desktop or Web';
        item.addEventListener('dragstart', (e) => {
            e.dataTransfer.effectAllowed = 'copy';

            // standard web drop (URL)
            e.dataTransfer.setData('text/uri-list', dataUrl);
            e.dataTransfer.setData('URL', dataUrl);
            e.dataTransfer.setData('text/plain', dataUrl);

            // OS File Drop (Chrome specific)
            e.dataTransfer.setData('DownloadURL', `${mimeType}:${fileName}:${dataUrl}`);

            if (mimeType.startsWith('image/')) {
                e.dataTransfer.setData('text/html', `<img src="${dataUrl}" alt="${fileName}">`);
            }
        });
    }

    gallery.appendChild(item);
    updateNavArrows();
}

// === Navigation Logic ===
const navLeft = document.getElementById('nav-left');
const navRight = document.getElementById('nav-right');

navLeft.addEventListener('click', () => {
    gallery.scrollBy({ left: -220, behavior: 'smooth' });
});

navRight.addEventListener('click', () => {
    gallery.scrollBy({ left: 220, behavior: 'smooth' });
});

gallery.addEventListener('scroll', updateNavArrows);

function updateNavArrows() {
    const scrollLeft = gallery.scrollLeft;
    const scrollWidth = gallery.scrollWidth;
    const clientWidth = gallery.clientWidth;

    if (scrollWidth <= clientWidth) {
        navLeft.classList.add('hidden');
        navRight.classList.add('hidden');
        return;
    }

    if (scrollLeft > 10) {
        navLeft.classList.remove('hidden');
    } else {
        navLeft.classList.add('hidden');
    }

    if (scrollLeft + clientWidth < scrollWidth - 1) {
        navRight.classList.remove('hidden');
    } else {
        navRight.classList.add('hidden');
    }
}


